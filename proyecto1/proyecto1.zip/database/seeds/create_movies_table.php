<?php

use Illuminate\Database\Seeder;

class create_movies_table extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
