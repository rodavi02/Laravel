<!DOCTYPE html>
<html>
<head>
	<title>Laravel Juanfran</title>
</head>
<body>
	
	<?php $__env->startSection('content'); ?>
		<div class="row">
			<div class="col-sm-4">
				<img src="<?php echo e($id->poster); ?>">
			</div>
			<div class="col-sm-8">
				<h4><strong><?php echo e($id->title); ?></strong></h4>
				<h6>Año: <?php echo e($id->year); ?></h6>
				<h6>Director: <?php echo e($id->director); ?></h6>
				<p><strong>Resumen:</strong> <?php echo e($id->synopsis); ?></p>
				<p>
					<strong>Estado:</strong> 
					<?php if($id->rented == false): ?>
						Película actualmente disponible.
						<br><br>
						<button type="button" class="btn btn-primary">Alquilar película</button>	
					<?php else: ?>
						Película actualmente alquilada.
						<br><br>
						<button type="button" class="btn btn-danger">Devolver película</button>
					<?php endif; ?>
					<a href="<?php echo e(url('catalog/edit/'.$id->id)); ?>"><button type="button" class="btn btn-warning">Editar película</button></a>
					<a class="btn" href="<?php echo e(url('/')); ?>"><button type="button" class="btn"> < Volver al listado</button></a>
				</p>
			</div>
		</div>
	<?php $__env->stopSection(); ?>
</body>
</html>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/proyecto1/resources/views/catalog/show.blade.php ENDPATH**/ ?>